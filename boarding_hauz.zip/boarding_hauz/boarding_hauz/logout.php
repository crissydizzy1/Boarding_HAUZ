<?php
require_once __DIR__ . '/auth.php';
logOut();
